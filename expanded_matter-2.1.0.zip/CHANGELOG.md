
# v2.1.0 - 2023-05-08 - Expanded Metals

## Bugfixes

* #33 - Fix: Crushed silver could not be obtained

## Vanilla Tweaks

* #48 - Cupronickel bits can be smelted into ingots
* #48 - Metal parts can be cut into cupronickel bits
* #46 - Electrum bits can be smelted into ingots

## New features

* #46 - Add crushed and powdered electrum
* #27 - Add crushed and powdered graphite

## Balancing

* #33 - Crushing ingots produces 20 crushed pieces

## Translations

* Add some missing language entries
* Fix typos

# v2.0.0 - 2023-04-21 - Powders and Ores

## Vanilla Tweaks

* #36 - Add descriptions to crushed and powdered metals and ores
* #32 - Crushed chromite can be used for tier 3 refractory bricks
* #29 - Dye can be crafted using the new powdered materials
* #26 - Now visible in barrels: powdered borax, powdered sulfur
* #26 - Kernite can be turned into borax
* #17 - Add pigment colors and names for: chromite, anthracite, fluorite
* #1 - Improve handbook entry for: corundum

## Bugfixes

* #43 - Crushed bauxite could not be ground into Powdered bauxite
* #41 - Bone ash visible as fertilizer on farm land
* #40 - Supress handbook entries for non-existing descriptions
* #37 - Handbook entries for crushed items appeared twice
* #33 - Fix: Crushing pentlandite ore yields same amount as crushing nuggets
* #33 - Fix: Impossible to crush some nuggets: cassiterite, chromite, ilmenite

## New features

* #42 - Crushed galena and sphalerite ores can be smelted down
* #39 - Most crushed metals can be smelted down
* #38 - For 1.18: Add crushed and powdered cupronickel
* #26 - Kernite can be turned into borax
* #1 - Add crushed luminous ores: phosphorite, uranium
* #1 - Add crushed luminous metals: uranium
* #1 - Add crushed ores: coal, corundum, galena, granite, hematite, limonite, magnetite, malachite, pentlandite, rhodochrosite, sphalerite
* #1 - Add crushed metals: copper, gold, lead, rusty, silver, tin, titanium, zinc
* #1 - Add powdered luminous ores: fluorite, phosphorite, redphosphorus, whitephoshorus
* #1 - Add powdered ores: bauxite, boneash, cassiterite, cinnabar, chromite, chromiumoxide, coal, corundum, galena, granite, hematite, ilmenite, kernite, lapislazuli, limonite, litharge, leadoxide, magnetite, malachite, massicot, olivine, pentlandite, rhodochrosite, quartz, sphalerite, whitelead, yellowcake, zinc oxide
* #1 - Add powdered metals: copper, gold, lead, nickel, rusty, silver, tin, uranium, zinc

## Translations

* Started Chinese translation
* Started Polish translation
* Started Swedish translation

## Testsuite

* #1 - Testsuite properly handles "skipVariants"
* #1 - Improve testsuite to check for missing handbook entries

# v1.1.2 - 2023-02-19 - Tweaks

## Balancing

* #19 - Increase output of ash-sludge by a factor of two

## Translations

* #24 - Add Japanese translation (Thanx, Macoto Hino!)
* #22 - Add Italian translation (Thanx x_Yota_x & Nahuel-Campos)

# v1.1.1 - 2023-01-30 - Tweaks

## Balancing

* #18 - increase sealing and drying times of ash

# v1.1.0 - 2022-11-13 - Ashes

## New features

* #14 - Add crafting of plant or wood ash and ash sludge. Disabled by default.
* #13 - Add French translation provided by Drakker

# v1.0.1 - 2022-09-18 - First Version

* #10 - Mark glass patches as server-side
* #9 - Add translation to creative tab names, put crushed temporal into Luminous tab

# v1.0.0 - 2022-08-31 - First Version

## New features

* #8 - Add spanish translation by Darce
* #2 - Add crushed temporal pieces and temporal dust
